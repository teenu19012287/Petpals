package com.petpals.exception;

public class InvalidPetAgeHandling extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidPetAgeHandling() {
		// TODO Auto-generated constructor stub
	}

	public InvalidPetAgeHandling(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
