package com.petpals.exception;

public class AdoptionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AdoptionException() {
		// TODO Auto-generated constructor stub
	}

	public AdoptionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
