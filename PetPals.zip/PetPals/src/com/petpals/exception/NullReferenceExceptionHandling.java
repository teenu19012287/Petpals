package com.petpals.exception;

public class NullReferenceExceptionHandling extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NullReferenceExceptionHandling() {
		// TODO Auto-generated constructor stub
	}

	public NullReferenceExceptionHandling(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
