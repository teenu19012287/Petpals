package com.petpals.exception;

public class FileHandlingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FileHandlingException() {
		// TODO Auto-generated constructor stub
	}

	public FileHandlingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
