package com.petpals.main;
import java.time.LocalDate;
import java.util.Scanner;


public class Main {


	public static void main(String[] args) {
	
		  Scanner sc = new Scanner(System.in);
	        int choice = -1;
            int innerChoice =-1;
	        while (choice != 0) {
	            // Display menu options
	            System.out.println("Pet System Menu:");
	            System.out.println("1.  Pet");
	            System.out.println("2.  Dog");
	            System.out.println("3.   Cat");
	            System.out.println("4.   PetShelter");
	            System.out.println("5.   Donation");
	            System.out.println("6.   Cash Donation");
	            System.out.println("7.   Item Donation");
	            System.out.println("8.   Adoption Event");
	            System.out.println("0. Exit");
	            System.out.print("Enter your choice: ");

	            choice = sc.nextInt();
	            sc.nextLine(); // Consume newline
	            
	            switch (choice) {
	                case 1:
	                	while(innerChoice !=0)
	                	{
	                		System.out.println("Following are the options:");
	    					System.out.println("1. Insert Pet");
	    					System.out.println("2. Update Pet");
	    					System.out.println("3. Delete Pet");
	    					System.out.println("4. View pet by ID");
	    					System.out.println("5. View all Pets");
	    					System.out.println("0. Exit");
	    					System.out.print("Please enter your choice: ");

	    					innerChoice = sc.nextInt();
	    					
	    					switch(innerChoice)
	    					{
	    					case 1:
	    						System.out.println("Insertion in Pets");
//	    						 studentService.insertStudent(new Student(1, "teenu", "Aswal", LocalDate.parse("1995-05-15"), "aswal@example.com", "1234567890"));
//	    					        studentService.insertStudent(new Student(2, "Yash", "Kanduri", LocalDate.parse("1998-08-25"), "yash@example.com", "9876543210"));
	    					        System.out.println("Enter student ID:");
	    					        int studentId = sc.nextInt();
	    					        sc.nextLine(); 

	    					        System.out.println("Enter student first name:");
	    					        String firstName = sc.nextLine();

	    					        System.out.println("Enter student last name:");
	    					        String lastName = sc.nextLine();

	    					        System.out.println("Enter student date of birth (YYYY-MM-DD):");
	    					        String dobS = sc.nextLine();
	    					        LocalDate dob = LocalDate.parse(dobS);
	    					        System.out.println("Enter student email:");
	    					        String email = sc.nextLine();

	    					        System.out.println("Enter student phone number:");
	    					        String phoneNumber = sc.nextLine();

	    					        
	    						break;
	    						
	    					case 2:
	    						System.out.println("Updation in Student");
	    						System.out.println("Enter student ID:");
    					        studentId = sc.nextInt();
    					        sc.nextLine(); 

    					        System.out.println("Enter student first name:");
    					        firstName = sc.nextLine();

    					        System.out.println("Enter student last name:");
    					        lastName = sc.nextLine();

    					        System.out.println("Enter student date of birth (YYYY-MM-DD):");
    					        dobS = sc.nextLine();
    					        dob = LocalDate.parse(dobS);
    					        System.out.println("Enter student email:");
    					        email = sc.nextLine();

    					        System.out.println("Enter student phone number:");
    					        phoneNumber = sc.nextLine();
    					       
    				
	    						break;
	    					case 3:
	    						System.out.println("Deletion in Student");
	    					
	    						System.out.println("Enter student ID to delete:");
    					        studentId = sc.nextInt();
    					        sc.nextLine();
    						
    					       
	    						break;
	    					case 4:
	    						System.out.println("View student by ID");
	    						 System.out.println("Enter student ID:");
	    					        studentId = sc.nextInt();
	    					        sc.nextLine(); 
	    					        
	    					      
	    						break;
	    					case 5:
	    						System.out.println("ALL records of students table:");
	    						
	    						break;
	    					        
	    					case 0:
	    						System.out.println("0. Exit");
	    											
	    					}
	    					
	    					   innerChoice = sc.nextInt();
	                	}
	                   
	                case 2:
	                	while(innerChoice !=0)
	                	{
	                		System.out.println("Following are the options:");
	    					System.out.println("1. Insert Course");
	    					System.out.println("2. Update Course");
	    					System.out.println("3. Delete Course");
	    					System.out.println("4. View Course by ID");
	    					System.out.println("5. View all Courses");
	    					System.out.println("0. Exit");
	    					System.out.print("Please enter your choice: ");

	    					innerChoice = sc.nextInt();
	    					
	    					switch(innerChoice)
	    					{
	    					case 1:
	    						System.out.println("1.Insertion in Course");
	    						break;
	    					case 2:
	    						System.out.println("2.Updation in Course");
	    						break;
	    					case 3:
	    						System.out.println("3.Deletion in Course");
	    						break;
	    					case 4:
	    						System.out.println("4.View Course by ID");
	    						break;
	    					case 5:
	    						System.out.println("5.ALL records of Course table:");
	    						break;
	    					case 0:
	    						System.out.println("0. Exit");
	    						break;
	    											
	    					}
	    					   innerChoice = sc.nextInt();
	    					
	                	}
	     
	                case 3:
	                	while(innerChoice !=0)
	                	{
	                		System.out.println("Following are the options:");
	    					System.out.println("1. Insert Enrollment");
	    					System.out.println("2. Update Enrollment");
	    					System.out.println("3. Delete Enrollment");
	    					System.out.println("4. View Enrollments by ID");
	    					System.out.println("5. View all Enrollments");
	    					System.out.println("0. Exit");
	    					System.out.print("Please enter your choice: ");

	    					innerChoice = sc.nextInt();
	    					
	    					switch(innerChoice)
	    					{
	    					case 1:
	    						System.out.println("1.Insertion in Enrollment");
	    						break;
	    					case 2:
	    						System.out.println("2.Updation in Enrollment");
	    						break;
	    					case 3:
	    						System.out.println("3.Deletion in Enrollment");
	    						break;
	    					case 4:
	    						System.out.println("4.View Enrollment by ID");
	    						break;
	    					case 5:
	    						System.out.println("5.ALL records of Enrollment table:");
	    						break;
	    					case 0:
	    						System.out.println("0. Exit");
	    						break;
	    											
	    					}
	    					   innerChoice = sc.nextInt();
	                	}
	                   
	                case 4:
	                	while(innerChoice !=0)
	                	{
	                		System.out.println("Following are the options:");
	    					System.out.println("1. Insert Teacher");
	    					System.out.println("2. Update Teacher");
	    					System.out.println("3. Delete Teacher");
	    					System.out.println("4. View Teacher by ID");
	    					System.out.println("5. View all Teachers");
	    					System.out.println("0. Exit");
	    					System.out.print("Please enter your choice: ");

	    					innerChoice = sc.nextInt();
	    					
	    					switch(innerChoice)
	    					{
	    					case 1:
	    						System.out.println("1.Insertion in Teacher");
	    						System.out.println("Enter Teacher ID:");
    					        int teacherId = sc.nextInt();
    					        sc.nextLine(); 

    					        System.out.println("Enter student first name:");
    					       String firstName = sc.nextLine();

    					        System.out.println("Enter student last name:");
    					       String lastName = sc.nextLine();

    					     
    					        System.out.println("Enter student email:");
    					       String email = sc.nextLine();
    					       
    					     
	    						
	    						break;
	    					case 2:
	    						System.out.println("2.Updation in Teacher");
	    						break;
	    					case 3:
	    						System.out.println("3.Deletion in Teacher");
	    						break;
	    					case 4:
	    						System.out.println("4.View Teacher by ID");
	    						break;
	    					case 5:
	    						System.out.println("5.ALL records of Teacher table:");
	    						break;
	    					case 0:
	    						System.out.println("0. Exit");
	    						break;
	    											
	    					}
	    					   innerChoice = sc.nextInt();
	                	}
	                	
	                case 5:
	                	while(innerChoice !=0)
	                	{
	                		System.out.println("Following are the options:");
	    					System.out.println("1. Insert Payment");
	    					System.out.println("2. Update Payment");
	    					System.out.println("3. Delete Payment");
	    					System.out.println("4. View Payments by ID");
	    					System.out.println("5. View all Payments");
	    					System.out.println("0. Exit");
	    					System.out.print("Please enter your choice: ");

	    					innerChoice = sc.nextInt();
	    					
	    					switch(innerChoice)
	    					{
	    					case 1:
	    						System.out.println("1.Insertion in Payment");
	    						break;
	    					case 2:
	    						System.out.println("2.Updation in Payment");
	    						break;
	    					case 3:
	    						System.out.println("3.Deletion in Payment");
	    						break;
	    					case 4:
	    						System.out.println("4.View Payment by ID");
	    						break;
	    					case 5:
	    						System.out.println("5.ALL records of Payment table:");
	    						break;
	    					case 0:
	    						System.out.println("6. Exit");
	    						break;
	    											
	    					}
	    					   innerChoice = sc.nextInt();
	                	}
	                   
	                case 0:
	                    System.out.println("Exiting...");
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please enter a valid option.");
	                    break;
	            }
	        }

	        sc.close();
		
           }
	        }
