package com.petpals.entity;

import java.util.ArrayList;
import java.util.List;

public class PetShelter {
    private List<Pet> availablePets;

    // Constructor
    public PetShelter() {
        availablePets = new ArrayList<>();
    }

    // Method to add a pet to the list of available pets
    public void addPet(Pet pet) {
        availablePets.add(pet);
    }

    // Method to remove a pet from the list of available pets
    public void removePet(Pet pet) {
        availablePets.remove(pet);
    }

    // Method to list all available pets in the shelter
    public void listAvailablePets() {
        System.out.println("Available Pets in the Shelter:");
        for (Pet pet : availablePets) {
            System.out.println(pet);
        }
    }
}

