package com.petpals.entity;
public class ItemDonation extends Donation {
    private String itemType;

    // Constructor
    public ItemDonation(String donorName, double amount, String itemType) {
        super(donorName, amount);
        this.itemType = itemType;
    }

    // Implementation of RecordDonation() for item donation
    @Override
    public void recordDonation() {
        // Logic to record an item donation
        System.out.println("Item donation of type " + itemType + " from " + getDonorName() + " of amount " + getAmount());
    }
}
