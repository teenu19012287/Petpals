package com.petpals.entity;

import java.time.LocalDateTime;

public class CashDonation extends Donation {
    private LocalDateTime donationDate;

    // Constructor
    public CashDonation(String donorName, double amount, LocalDateTime donationDate) {
        super(donorName, amount);
        this.donationDate = donationDate;
    }

    // Implementation of RecordDonation() for cash donation
    @Override
    public void recordDonation() {
        // Logic to record a cash donation
        System.out.println("Cash donation recorded on " + donationDate + " from " + getDonorName() + " of amount " + getAmount());
    }
}
