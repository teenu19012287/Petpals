package com.petpals.entity;

import java.util.ArrayList;
import java.util.List;

import com.petpals.dao.IAdoptable;

public class AdoptionEvent {
	 private List<IAdoptable> participants;

	    public AdoptionEvent() {
	        participants = new ArrayList<>();
	    }

	    public void hostEvent() {
	        System.out.println("Adoption event hosted!");
	        // Logic for hosting the adoption event
	    }

	    public void registerParticipant(IAdoptable participant) {
	        participants.add(participant);
	        System.out.println("Participant registered for the event!");
	        // Additional logic for registering a participant
    }
}
