package com.petpals.entity;

public abstract class Donation {
    private String donorName;
    private double amount;

    // Constructor
    public Donation(String donorName, double amount) {
        this.donorName = donorName;
        this.amount = amount;
    }

    // Abstract method to record donation (to be implemented in derived classes)
    public abstract void recordDonation();

    // Getters and setters
    public String getDonorName() {
        return donorName;
    }

    public void setDonorName(String donorName) {
        this.donorName = donorName;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
