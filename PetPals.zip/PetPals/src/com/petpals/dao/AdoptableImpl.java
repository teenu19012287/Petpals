package com.petpals.dao;

public class AdoptableImpl {

	public AdoptableImpl() {
		// TODO Auto-generated constructor stub
	}

}
