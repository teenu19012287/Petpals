package com.petpals.dao;

public class IAdoptable {
	  void adopt() {
	}
}
